﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAC627_Project.UserControls.Prefabs
{
    public partial class MessageHistory : UserControl
    {
        public MessageHistory()
        {
            InitializeComponent();
        }
    }
}
